import React from 'react';
export default function PatientList() {
  return <div>Patient List Coming Soon</div>;
}