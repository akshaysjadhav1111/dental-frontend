import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:8080/api',
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const loginApi = (data) => API.post('/auth/login', data);
export const getPatientsApi = () => API.get('/patients');
export const addPatientApi = (data) => API.post('/patients', data);
export const getPatientApi = (id) => API.get(`/patients/${id}`);
export const updatePatientApi = (id, data) => API.put(`/patients/${id}`, data);
export const deletePatientApi = (id) => API.delete(`/patients/${id}`);
export const searchPatientsApi = (q) => API.get(`/patients/search?q=${q}`);
export const getStatsApi = () => API.get('/patients/stats');