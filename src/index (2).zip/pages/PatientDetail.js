import React from 'react';
export default function PatientDetail() {
  return <div>Patient Detail Coming Soon</div>;
}