import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getPatientsApi, getStatsApi } from '../services/api';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { doctor, logout } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ total: 0, today: 0, followups: 0, reports: 0 });
  const [recentPatients, setRecentPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeNav, setActiveNav] = useState('/');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      const [pRes, sRes] = await Promise.all([getPatientsApi(), getStatsApi()]);
      setRecentPatients(pRes.data.slice(0, 6));
      setStats(sRes.data);
    } catch { toast.error('Failed to load data'); }
    finally { setLoading(false); }
  };

  const hour = new Date().getHours();
  const greeting = hour < 12 ? '🌅 Good Morning' : hour < 17 ? '☀️ Good Afternoon' : '🌙 Good Evening';

  return (
    <div style={s.root}>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes fadeLeft { from{opacity:0;transform:translateX(-20px)} to{opacity:1;transform:translateX(0)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
        @keyframes glow { 0%,100%{box-shadow:0 0 0 0 rgba(13,148,136,0.3)} 50%{box-shadow:0 0 0 8px rgba(13,148,136,0)} }
        @keyframes moveBg { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        @keyframes floatOrb1 { 0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(40px,-30px) scale(1.1)} }
        @keyframes floatOrb2 { 0%,100%{transform:translate(0,0) scale(1)} 50%{transform:translate(-30px,40px) scale(0.95)} }
        @keyframes floatOrb3 { 0%,100%{transform:translate(0,0)} 50%{transform:translate(20px,20px)} }
        .main-bg { background: linear-gradient(135deg, #0a1628 0%, #0d3d38 40%, #0a2a2a 70%, #0d1f3c 100%) !important; background-size: 400% 400% !important; animation: moveBg 12s ease infinite !important; }

        .nav-item:hover { background:rgba(13,148,136,0.2) !important; color:#5eead4 !important; padding-left:22px !important; }
        .stat-card:hover { transform:translateY(-8px) !important; }
        .patient-row:hover { background:linear-gradient(90deg,#f0fdfa,#fff) !important; }
        .view-btn:hover { background:#0f766e !important; transform:scale(1.08) !important; letter-spacing:1px; }
        .action-btn:hover { transform:translateY(-4px) !important; filter:brightness(1.1); }
        .logout-btn:hover { background:rgba(239,68,68,0.12) !important; color:#fca5a5 !important; }
        .see-all:hover { background:#0d9488 !important; color:#fff !important; }
        * { box-sizing:border-box; }
        ::-webkit-scrollbar { width:5px; }
        ::-webkit-scrollbar-thumb { background:#0d9488; border-radius:4px; }
      `}</style>

      {/* SIDEBAR */}
      <div style={s.sidebar}>
        {/* Logo */}
        <div style={s.logoBox}>
          <div style={s.logoCircle}>🦷</div>
          <div>
            <div style={s.logoName}>Sharnya Smile Care</div>
            <div style={s.logoSub}>Dental Management</div>
          </div>
        </div>

        <div style={s.divider} />

        {/* Nav */}
        <nav style={{ padding:'0 10px', flex:1 }}>
          {[
            { icon:'🏠', label:'Dashboard', path:'/' },
            { icon:'➕', label:'Add Patient', path:'/add-patient' },
            { icon:'📋', label:'All Patients', path:'/patients' },
          ].map(item => (
            <div key={item.path} className="nav-item"
              onClick={() => { setActiveNav(item.path); navigate(item.path); }}
              style={{ ...s.navItem, ...(activeNav===item.path ? s.navActive : {}) }}>
              <span style={{fontSize:18}}>{item.icon}</span>
              <span>{item.label}</span>
              {activeNav===item.path && <div style={s.navDot}/>}
            </div>
          ))}
        </nav>

        <div style={s.divider} />

        {/* Doctor info */}
        <div style={s.docCard}>
          <div style={s.docAvatar}>👨‍⚕️</div>
          <div>
            <div style={s.docName}>{doctor?.doctorName}</div>
            <div style={s.docRole}>Dental Surgeon</div>
          </div>
        </div>

        <div className="logout-btn" onClick={() => { logout(); navigate('/login'); }} style={s.logoutBtn}>
          <span>🚪</span><span>Logout</span>
        </div>
      </div>

      {/* MAIN */}
      <div style={s.main} className="main-bg">
        {/* Animated background orbs */}
        <div style={{position:'fixed',inset:0,zIndex:0,pointerEvents:'none',overflow:'hidden',marginLeft:240}}>
          <div style={{position:'absolute',width:500,height:500,borderRadius:'50%',background:'radial-gradient(circle,rgba(13,148,136,0.18) 0%,transparent 70%)',top:'-100px',right:'10%',animation:'floatOrb1 10s ease-in-out infinite'}}/>
          <div style={{position:'absolute',width:400,height:400,borderRadius:'50%',background:'radial-gradient(circle,rgba(6,182,212,0.12) 0%,transparent 70%)',bottom:'5%',right:'30%',animation:'floatOrb2 14s ease-in-out infinite'}}/>
          <div style={{position:'absolute',width:300,height:300,borderRadius:'50%',background:'radial-gradient(circle,rgba(20,184,166,0.1) 0%,transparent 70%)',top:'40%',right:'5%',animation:'floatOrb3 8s ease-in-out infinite'}}/>
          <div style={{position:'absolute',width:200,height:200,borderRadius:'50%',background:'radial-gradient(circle,rgba(13,148,136,0.15) 0%,transparent 70%)',bottom:'20%',left:'5%',animation:'floatOrb1 12s ease-in-out infinite reverse'}}/>
        </div>

        {/* Top header bar */}
        <div style={s.topBar}>
          <div style={{animation:'fadeUp 0.5s ease'}}>
            <div style={s.greetText}>{greeting},</div>
            <div style={s.drName}>{doctor?.doctorName}</div>
            <div style={s.dateText}>
              📅 {new Date().toLocaleDateString('en-IN',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}
            </div>
          </div>
          <div style={s.topBtns}>
            <button className="action-btn" onClick={() => navigate('/add-patient')} style={s.btnPrimary}>➕ New Patient</button>
            <button className="action-btn" onClick={() => navigate('/patients')} style={s.btnOutline}>📋 All Patients</button>
          </div>
        </div>

        {/* STAT CARDS */}
        <div style={s.statsGrid}>
          {[
            { icon:'👥', label:'Total Patients',  value:stats.total,      grad:'linear-gradient(135deg,#0d9488 0%,#0f766e 100%)', glow:'rgba(13,148,136,0.5)',  bar:'#5eead4' },
            { icon:'🗓️', label:"Today's Visits",  value:stats.today,      grad:'linear-gradient(135deg,#0369a1 0%,#0284c7 100%)', glow:'rgba(3,105,161,0.5)',   bar:'#7dd3fc' },
            { icon:'🔔', label:'Follow-ups',       value:stats.followups,  grad:'linear-gradient(135deg,#0f766e 0%,#14b8a6 100%)', glow:'rgba(20,184,166,0.5)',  bar:'#a7f3d0' },
            { icon:'📋', label:'Reports',          value:stats.reports||0, grad:'linear-gradient(135deg,#1e40af 0%,#2563eb 100%)', glow:'rgba(37,99,235,0.5)',   bar:'#93c5fd' },
          ].map((c,i) => (
            <div key={c.label} className="stat-card" style={{
              ...s.statCard,
              background: c.grad,
              boxShadow:`0 8px 32px ${c.glow}`,
              border:'1px solid rgba(255,255,255,0.15)',
              animation:`fadeUp 0.5s ease ${i*0.1}s both`,
            }}>
              {/* Top row */}
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16}}>
                <div style={{background:'rgba(255,255,255,0.2)',borderRadius:14,width:52,height:52,display:'flex',alignItems:'center',justifyContent:'center',fontSize:26,backdropFilter:'blur(8px)'}}>
                  {c.icon}
                </div>

              </div>
              {/* Value */}
              <div style={{fontSize:48,fontWeight:900,color:'#ffffff',lineHeight:1,marginBottom:6,textShadow:'0 2px 8px rgba(0,0,0,0.2)'}}>
                {loading ? <span style={{animation:'pulse 1s infinite',fontSize:32}}>—</span> : c.value}
              </div>
              {/* Label */}
              <div style={{color:'rgba(255,255,255,0.85)',fontSize:14,fontWeight:600,marginBottom:14,letterSpacing:'0.3px'}}>
                {c.label}
              </div>
              {/* Bar */}
              <div style={{height:5,borderRadius:4,background:'rgba(255,255,255,0.2)',overflow:'hidden'}}>
                <div style={{height:'100%',width:'65%',background:c.bar,borderRadius:4,boxShadow:`0 0 8px ${c.bar}`}}/>
              </div>
            </div>
          ))}
        </div>

        {/* BOTTOM SECTION */}
        <div style={s.bottomGrid}>

          {/* Recent Patients */}
          <div style={{...s.card, flex:2, animation:'fadeUp 0.6s ease 0.3s both'}}>
            <div style={s.cardHead}>
              <div style={s.cardTitle}>🧑‍⚕️ Recent Patients</div>
              <button className="see-all" onClick={() => navigate('/patients')} style={s.seeAll}>See All →</button>
            </div>
            {loading ? (
              <p style={s.empty}>⏳ Loading...</p>
            ) : recentPatients.length === 0 ? (
              <div style={{textAlign:'center', padding:'40px 0'}}>
                <div style={{fontSize:52, marginBottom:12}}>🦷</div>
                <p style={s.empty}>No patients yet!</p>
                <button onClick={() => navigate('/add-patient')} style={s.addBtn}>+ Add First Patient</button>
              </div>
            ) : (
              <div style={{overflowX:'auto'}}>
                <table style={s.table}>
                  <thead>
                    <tr>{['#','Patient Name','Age','Contact','Status','Action'].map(h=>(
                      <th key={h} style={s.th}>{h}</th>
                    ))}</tr>
                  </thead>
                  <tbody>
                    {recentPatients.map((p,i) => (
                      <tr key={p.id} className="patient-row"
                        onClick={() => navigate(`/patients/${p.id}`)}
                        style={{cursor:'pointer', transition:'all 0.2s'}}>
                        <td style={s.td}>
                          <div style={s.numBadge}>{i+1}</div>
                        </td>
                        <td style={s.td}>
                          <div style={s.pName}>{p.name}</div>
                          <div style={s.pSub}>{p.email || 'No email'}</div>
                        </td>
                        <td style={s.td}><span style={s.agePill}>{p.age} yrs</span></td>
                        <td style={s.td}><span style={{color:'#475569'}}>{p.contactNumber}</span></td>
                        <td style={s.td}><span style={s.statusBadge}>Active</span></td>
                        <td style={s.td}>
                          <button className="view-btn"
                            onClick={e=>{e.stopPropagation();navigate(`/patients/${p.id}`);}}
                            style={s.viewBtn}>View →</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Right column */}
          <div style={{display:'flex', flexDirection:'column', gap:20, flex:1, minWidth:240}}>

            {/* Doctor image card */}
            <div style={{...s.card, padding:0, overflow:'hidden', animation:'fadeUp 0.6s ease 0.4s both'}}>
              <div style={{position:'relative', height:200}}>
                <img src="/doctor-bg.jpg" alt="doctor" style={{width:'100%',height:'100%',objectFit:'cover',filter:'brightness(0.75) saturate(0.9)'}}/>
                <div style={{position:'absolute',inset:0,background:'linear-gradient(to top, rgba(10,22,40,0.9) 0%, transparent 60%)'}}/>
                <div style={{position:'absolute',bottom:0,left:0,padding:18}}>
                  <div style={{color:'#5eead4',fontSize:11,fontWeight:700,letterSpacing:2,textTransform:'uppercase',marginBottom:4}}>Our Promise</div>
                  <div style={{color:'#fff',fontWeight:800,fontSize:16}}>Excellence in Dental Care</div>
                  <div style={{color:'rgba(255,255,255,0.65)',fontSize:12,marginTop:2}}>Sharnya Smile Care</div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div style={{...s.card, animation:'fadeUp 0.6s ease 0.5s both'}}>
              <div style={{...s.cardTitle, marginBottom:14}}>⚡ Quick Actions</div>
              {[
                { icon:'➕', label:'Add New Patient', path:'/add-patient', color:'#0d9488' },
                { icon:'📋', label:'Patient Records',  path:'/patients',    color:'#0369a1' },
              ].map(a => (
                <button key={a.label} className="action-btn" onClick={() => navigate(a.path)}
                  style={{...s.quickBtn, borderLeft:`4px solid ${a.color}`, color:a.color}}>
                  <span style={{fontSize:18}}>{a.icon}</span>
                  <span style={{flex:1, textAlign:'left'}}>{a.label}</span>
                  <span style={{opacity:0.5}}>→</span>
                </button>
              ))}
            </div>

            {/* Today summary */}
            <div style={{...s.card, background:'linear-gradient(135deg,#0d9488,#0a1628)', animation:'fadeUp 0.6s ease 0.6s both'}}>
              <div style={{color:'#5eead4',fontSize:12,fontWeight:700,letterSpacing:2,textTransform:'uppercase',marginBottom:12}}>Today's Summary</div>
              {[
                { label:'Appointments', val: stats.today || 0 },
                { label:'Follow-ups Due', val: stats.followups || 0 },
              ].map(item => (
                <div key={item.label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                  <span style={{color:'rgba(255,255,255,0.7)',fontSize:13}}>{item.label}</span>
                  <span style={{color:'#fff',fontWeight:800,fontSize:18}}>{item.val}</span>
                </div>
              ))}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

const s = {
  root:{ display:'flex', minHeight:'100vh', background:'#f1f5f9', fontFamily:"'Segoe UI',sans-serif" },

  // Sidebar
  sidebar:{ width:240, background:'linear-gradient(180deg,#0a1628 0%,#0d2d2a 100%)', display:'flex', flexDirection:'column', position:'fixed', top:0, left:0, height:'100vh', zIndex:100, boxShadow:'4px 0 32px rgba(0,0,0,0.25)' },
  logoBox:{ display:'flex', alignItems:'center', gap:12, padding:'28px 20px 20px' },
  logoCircle:{ fontSize:32, background:'rgba(13,148,136,0.25)', borderRadius:14, width:50, height:50, display:'flex', alignItems:'center', justifyContent:'center' },
  logoName:{ color:'#fff', fontWeight:800, fontSize:13 },
  logoSub:{ color:'#5eead4', fontSize:11, marginTop:2 },
  divider:{ height:1, background:'rgba(255,255,255,0.07)', margin:'4px 16px' },
  navItem:{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderRadius:12, color:'rgba(255,255,255,0.6)', cursor:'pointer', fontSize:14, fontWeight:500, marginBottom:4, position:'relative', transition:'all 0.25s ease' },
  navActive:{ background:'rgba(13,148,136,0.25)', color:'#5eead4', fontWeight:700 },
  navDot:{ position:'absolute', right:12, width:6, height:6, borderRadius:'50%', background:'#0d9488' },
  docCard:{ display:'flex', alignItems:'center', gap:10, margin:'8px 12px', background:'rgba(255,255,255,0.05)', borderRadius:12, padding:'12px 14px' },
  docAvatar:{ fontSize:26, background:'rgba(13,148,136,0.25)', borderRadius:'50%', width:42, height:42, display:'flex', alignItems:'center', justifyContent:'center' },
  docName:{ color:'#fff', fontSize:12, fontWeight:700 },
  docRole:{ color:'#5eead4', fontSize:11 },
  logoutBtn:{ display:'flex', alignItems:'center', gap:10, padding:'14px 24px', color:'rgba(255,255,255,0.45)', cursor:'pointer', fontSize:13, borderRadius:12, margin:'0 10px 16px', transition:'all 0.2s' },

  // Main
  main:{ marginLeft:240, flex:1, padding:'0 0 32px', position:'relative', minHeight:'100vh' },

  // Top bar
  topBar:{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'28px 28px 20px', flexWrap:'wrap', gap:16, background:'rgba(255,255,255,0.05)', backdropFilter:'blur(16px)', borderBottom:'1px solid rgba(255,255,255,0.08)', marginBottom:24, position:'relative', zIndex:1 },
  greetText:{ color:'#5eead4', fontSize:13, fontWeight:600, marginBottom:2 },
  drName:{ color:'#ffffff', fontSize:'clamp(20px,2.5vw,28px)', fontWeight:800, margin:'0 0 4px' },
  dateText:{ color:'rgba(255,255,255,0.45)', fontSize:13 },
  topBtns:{ display:'flex', gap:12, flexWrap:'wrap' },
  btnPrimary:{ padding:'11px 22px', background:'linear-gradient(135deg,#0d9488,#0f766e)', color:'#fff', border:'none', borderRadius:12, fontWeight:700, fontSize:14, cursor:'pointer', boxShadow:'0 4px 20px rgba(13,148,136,0.5)', transition:'all 0.2s' },
  btnOutline:{ padding:'11px 22px', background:'rgba(255,255,255,0.08)', color:'#5eead4', border:'1.5px solid rgba(94,234,212,0.4)', borderRadius:12, fontWeight:700, fontSize:14, cursor:'pointer', backdropFilter:'blur(8px)', transition:'all 0.2s' },

  // Stats
  statsGrid:{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:20, padding:'0 28px 24px', position:'relative', zIndex:1 },
  statCard:{ borderRadius:20, padding:'22px 20px', cursor:'default', transition:'transform 0.25s ease, box-shadow 0.25s ease', backdropFilter:'blur(16px)', border:'1px solid rgba(255,255,255,0.12)' },
  statIconWrap:{ width:52, height:52, borderRadius:14, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:14 },
  statVal:{ fontSize:42, fontWeight:900, lineHeight:1, marginBottom:4 },
  statLbl:{ color:'rgba(255,255,255,0.65)', fontSize:13, fontWeight:600, marginBottom:12 },
  statBar:{ height:6, borderRadius:4, overflow:'hidden' },

  // Bottom
  bottomGrid:{ display:'flex', gap:20, padding:'0 28px', flexWrap:'wrap', position:'relative', zIndex:1 },

  // Card
  card:{ background:'rgba(255,255,255,0.07)', backdropFilter:'blur(20px)', border:'1px solid rgba(255,255,255,0.12)', borderRadius:20, padding:24, boxShadow:'0 8px 32px rgba(0,0,0,0.2)' },
  cardHead:{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18 },
  cardTitle:{ fontSize:16, fontWeight:700, color:'#ffffff' },
  seeAll:{ background:'rgba(13,148,136,0.2)', color:'#5eead4', border:'1px solid rgba(94,234,212,0.3)', padding:'6px 14px', borderRadius:8, cursor:'pointer', fontSize:12, fontWeight:700, transition:'all 0.2s' },

  // Table
  table:{ width:'100%', borderCollapse:'collapse' },
  th:{ textAlign:'left', padding:'10px 14px', color:'rgba(255,255,255,0.4)', fontSize:11, fontWeight:700, letterSpacing:'0.8px', textTransform:'uppercase', borderBottom:'1px solid rgba(255,255,255,0.08)' },
  td:{ padding:'13px 14px', borderBottom:'1px solid rgba(255,255,255,0.05)', verticalAlign:'middle', transition:'all 0.2s' },
  numBadge:{ width:28, height:28, borderRadius:'50%', background:'linear-gradient(135deg,#0d9488,#0f766e)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:700 },
  pName:{ fontWeight:700, color:'#ffffff', fontSize:14 },
  pSub:{ color:'rgba(255,255,255,0.4)', fontSize:12, marginTop:2 },
  agePill:{ background:'rgba(13,148,136,0.2)', color:'#5eead4', padding:'3px 10px', borderRadius:20, fontSize:12, fontWeight:600, border:'1px solid rgba(94,234,212,0.2)' },
  statusBadge:{ background:'rgba(22,163,74,0.2)', color:'#4ade80', padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:700, border:'1px solid rgba(74,222,128,0.2)' },
  viewBtn:{ background:'linear-gradient(135deg,#0d9488,#0f766e)', color:'#fff', border:'none', padding:'7px 14px', borderRadius:8, cursor:'pointer', fontSize:12, fontWeight:600, transition:'all 0.2s', boxShadow:'0 2px 8px rgba(13,148,136,0.3)' },

  empty:{ textAlign:'center', color:'rgba(255,255,255,0.4)', padding:'20px 0', fontSize:14 },
  addBtn:{ background:'linear-gradient(135deg,#0d9488,#0f766e)', color:'#fff', border:'none', padding:'10px 24px', borderRadius:10, cursor:'pointer', fontWeight:600, marginTop:8, fontSize:14 },

  quickBtn:{ width:'100%', display:'flex', alignItems:'center', gap:12, padding:'13px 16px', background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, cursor:'pointer', fontSize:14, fontWeight:600, marginBottom:10, transition:'all 0.2s' },
};