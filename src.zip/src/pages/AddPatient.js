import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addPatientApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function AddPatient() {
  const navigate = useNavigate();
  const { doctor, logout } = useAuth();
  const [activeNav, setActiveNav] = useState('/add-patient');
  const [loading, setLoading] = useState(false);
  const [pdfFile, setPdfFile] = useState(null);
  const [form, setForm] = useState({
    name:'', age:'', gender:'', contactNumber:'',
    email:'', address:'', bloodGroup:'',
    medicalHistory:'', allergies:'', chronicConditions:'', description:'', chiefComplaint:'',
  });

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handlePdf = e => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
      toast.success(`📄 "${file.name}" selected!`);
    } else {
      toast.error('Please select a valid PDF file!');
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        name: form.name,
        age: form.age,
        gender: form.gender,
        contactNumber: form.contactNumber,
        email: form.email,
        address: form.address,
        bloodGroup: form.bloodGroup,
        medicalHistory: form.medicalHistory,
        allergies: form.allergies,
        chronicConditions: form.chronicConditions,
        chiefComplaint: form.description,
        dentalHistory: form.description,
        description: form.description,
      };
      console.log('Sending payload:', payload);
      await addPatientApi(payload);
      toast.success('Patient added successfully! 🎉');
      navigate('/patients');
    } catch (err) {
      console.error('Save error:', err.response?.data);
      toast.error('Failed to add patient: ' + (err.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  const navItems = [
    { icon:'🏠', label:'Dashboard', path:'/' },
    { icon:'➕', label:'Add Patient', path:'/add-patient' },
    { icon:'📋', label:'All Patients', path:'/patients' },
  ];

  return (
    <div style={s.root}>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes floatOrb1 { 0%,100%{transform:translate(0,0)} 50%{transform:translate(40px,-30px)} }
        @keyframes floatOrb2 { 0%,100%{transform:translate(0,0)} 50%{transform:translate(-30px,40px)} }
        .nav-item:hover { background:rgba(13,148,136,0.2) !important; color:#5eead4 !important; padding-left:22px !important; }
        .logout-btn:hover { background:rgba(239,68,68,0.12) !important; color:#fca5a5 !important; }
        .input-field:focus { border-color:rgba(94,234,212,0.7) !important; background:rgba(13,148,136,0.12) !important; box-shadow:0 0 0 3px rgba(13,148,136,0.15) !important; }
        .input-field::placeholder { color:rgba(255,255,255,0.3); }
        .input-field option { background:#0d3d38; color:#fff; padding:10px; }
        select.input-field { color:#fff; cursor:pointer; }
        select.input-field option { background:#0a2520 !important; color:#ffffff !important; font-size:14px; padding:8px; }
        .submit-btn:hover { transform:translateY(-3px) !important; box-shadow:0 12px 32px rgba(13,148,136,0.55) !important; }
        .cancel-btn:hover { background:rgba(255,255,255,0.1) !important; color:#fff !important; }
        .back-btn:hover { background:rgba(13,148,136,0.2) !important; }
        .pdf-zone:hover { border-color:rgba(94,234,212,0.6) !important; background:rgba(13,148,136,0.12) !important; }
        ::-webkit-scrollbar { width:5px; }
        ::-webkit-scrollbar-thumb { background:#0d9488; border-radius:4px; }
      `}</style>

      {/* SIDEBAR */}
      <div style={s.sidebar}>
        <div style={s.logoBox}>
          <div style={s.logoCircle}>🦷</div>
          <div>
            <div style={s.logoName}>Sharnya Smile Care</div>
            <div style={s.logoSub}>Dental Management</div>
          </div>
        </div>
        <div style={s.divider}/>
        <nav style={{padding:'0 10px',flex:1}}>
          {navItems.map(item=>(
            <div key={item.path} className="nav-item"
              onClick={()=>{setActiveNav(item.path);navigate(item.path);}}
              style={{...s.navItem,...(activeNav===item.path?s.navActive:{})}}>
              <span style={{fontSize:18}}>{item.icon}</span>
              <span>{item.label}</span>
              {activeNav===item.path&&<div style={s.navDot}/>}
            </div>
          ))}
        </nav>
        <div style={s.divider}/>
        <div style={s.docCard}>
          <div style={s.docAvatar}>👨‍⚕️</div>
          <div>
            <div style={s.docName}>{doctor?.doctorName}</div>
            <div style={s.docRole}>Dental Surgeon</div>
          </div>
        </div>
        <div className="logout-btn" onClick={()=>{logout();navigate('/login');}} style={s.logoutBtn}>
          <span>🚪</span><span>Logout</span>
        </div>
      </div>

      {/* MAIN */}
      <div style={s.main}>
        {/* Orbs */}
        <div style={{position:'fixed',inset:0,zIndex:0,pointerEvents:'none',overflow:'hidden',marginLeft:240}}>
          <div style={{position:'absolute',width:500,height:500,borderRadius:'50%',background:'radial-gradient(circle,rgba(13,148,136,0.15) 0%,transparent 70%)',top:'-100px',right:'10%',animation:'floatOrb1 10s ease-in-out infinite'}}/>
          <div style={{position:'absolute',width:350,height:350,borderRadius:'50%',background:'radial-gradient(circle,rgba(6,182,212,0.1) 0%,transparent 70%)',bottom:'10%',right:'5%',animation:'floatOrb2 14s ease-in-out infinite'}}/>
        </div>

        {/* Top bar */}
        <div style={s.topBar}>
          <div>
            <div style={s.pageTitle}>➕ Add New Patient</div>
            <div style={s.pageSub}>Fill in the details to register a new patient</div>
          </div>
          <button className="back-btn" onClick={()=>navigate('/patients')} style={s.backBtn}>← Back to Patients</button>
        </div>

        <form onSubmit={handleSubmit} style={{padding:'0 28px 40px',position:'relative',zIndex:1}}>

          {/* SECTION 1 — Basic Info */}
          <div style={{...s.section,animation:'fadeUp 0.5s ease 0.1s both'}}>
            <div style={s.sectionHead}>
              <div style={s.sIcon}>👤</div>
              <div>
                <div style={s.sTitle}>Basic Information</div>
                <div style={s.sSub}>Patient's personal & contact details</div>
              </div>
            </div>
            <div style={s.grid2}>

              <Field label="Full Name *">
                <input className="input-field" type="text" name="name" value={form.name}
                  onChange={handleChange} placeholder="Enter full name" required style={s.inp}/>
              </Field>

              <Field label="Age *">
                <input className="input-field" type="number" name="age" value={form.age}
                  onChange={handleChange} placeholder="Enter age" required min="1" max="120" style={s.inp}/>
              </Field>

              <Field label="Gender *">
                <select className="input-field" name="gender" value={form.gender}
                  onChange={handleChange} required style={s.inp}>
                  <option value="" disabled>Select gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </Field>

              <Field label="Blood Group">
                <select className="input-field" name="bloodGroup" value={form.bloodGroup}
                  onChange={handleChange} style={s.inp}>
                  <option value="" disabled>Select blood group</option>
                  {['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(b=>(
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </Field>

              <Field label="Contact Number *">
                <input className="input-field" type="tel" name="contactNumber" value={form.contactNumber}
                  onChange={handleChange} placeholder="Enter phone number" required style={s.inp}/>
              </Field>

              <Field label="Email Address">
                <input className="input-field" type="email" name="email" value={form.email}
                  onChange={handleChange} placeholder="Enter email address" style={s.inp}/>
              </Field>

              <Field label="Address" full>
                <input className="input-field" type="text" name="address" value={form.address}
                  onChange={handleChange} placeholder="Enter full address" style={s.inp}/>
              </Field>

            </div>
          </div>

          {/* SECTION 2 — Medical Info */}
          <div style={{...s.section,animation:'fadeUp 0.5s ease 0.2s both'}}>
            <div style={s.sectionHead}>
              <div style={s.sIcon}>🏥</div>
              <div>
                <div style={s.sTitle}>Medical Information</div>
                <div style={s.sSub}>Health background & dental concerns</div>
              </div>
            </div>
            <div style={s.grid2}>
              {[
                {label:'Medical History', name:'medicalHistory', ph:'Previous surgeries, treatments, dental history...'},
                {label:'Known Allergies', name:'allergies', ph:'Penicillin, latex, metals...'},
                {label:'Chronic Conditions', name:'chronicConditions', ph:'Diabetes, BP, Asthma, Heart conditions...'},
                {label:'Chief Complaint / Description', name:'description', ph:'Main reason for visit, symptoms, pain details...'},
              ].map(f=>(
                <Field key={f.name} label={f.label}>
                  <textarea className="input-field" name={f.name} value={form[f.name]}
                    onChange={handleChange} placeholder={f.ph} rows={3}
                    style={{...s.inp, resize:'vertical', minHeight:80}}/>
                </Field>
              ))}
            </div>
          </div>

          {/* SECTION 3 — Report Upload */}
          <div style={{...s.section,animation:'fadeUp 0.5s ease 0.3s both'}}>
            <div style={s.sectionHead}>
              <div style={s.sIcon}>📄</div>
              <div>
                <div style={s.sTitle}>Lab Report / Document</div>
                <div style={s.sSub}>Upload PDF report (optional — can be added later via Edit)</div>
              </div>
            </div>

            <label htmlFor="pdf-upload" className="pdf-zone" style={s.pdfZone}>
              <input id="pdf-upload" type="file" accept="application/pdf" onChange={handlePdf} style={{display:'none'}}/>
              {pdfFile ? (
                <div style={{textAlign:'center'}}>
                  <div style={{fontSize:40,marginBottom:8}}>📄</div>
                  <div style={{color:'#5eead4',fontWeight:700,fontSize:15}}>{pdfFile.name}</div>
                  <div style={{color:'rgba(255,255,255,0.4)',fontSize:12,marginTop:4}}>
                    {(pdfFile.size/1024).toFixed(1)} KB — Click to change
                  </div>
                </div>
              ) : (
                <div style={{textAlign:'center'}}>
                  <div style={{fontSize:40,marginBottom:8}}>📂</div>
                  <div style={{color:'rgba(255,255,255,0.7)',fontWeight:600,fontSize:15}}>Click to upload Lab Report PDF</div>
                  <div style={{color:'rgba(255,255,255,0.35)',fontSize:12,marginTop:6}}>Only PDF files • Max 10MB • Can also add later via Edit Patient</div>
                </div>
              )}
            </label>
          </div>

          {/* ACTION BUTTONS */}
          <div style={{display:'flex',gap:14,justifyContent:'flex-end',animation:'fadeUp 0.5s ease 0.4s both',flexWrap:'wrap'}}>
            <button type="button" className="cancel-btn" onClick={()=>navigate('/patients')} style={s.cancelBtn}>
              ✕ Cancel
            </button>
            <button type="submit" className="submit-btn" disabled={loading}
              style={{...s.submitBtn,opacity:loading?0.7:1,cursor:loading?'not-allowed':'pointer'}}>
              {loading ? '⏳ Saving Patient...' : '✅ Save Patient'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

// Reusable field wrapper
function Field({ label, children, full }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8, gridColumn: full ? '1/-1' : undefined }}>
      <label style={{ color:'rgba(255,255,255,0.65)', fontSize:11, fontWeight:700, letterSpacing:'1px', textTransform:'uppercase' }}>
        {label}
      </label>
      {children}
    </div>
  );
}

const s = {
  root:{ display:'flex', minHeight:'100vh', fontFamily:"'Segoe UI',sans-serif", background:'linear-gradient(135deg,#0a1628 0%,#0d3d38 40%,#0a2a2a 70%,#0d1f3c 100%)' },
  sidebar:{ width:240, background:'linear-gradient(180deg,#0a1628 0%,#0d2d2a 100%)', display:'flex', flexDirection:'column', position:'fixed', top:0, left:0, height:'100vh', zIndex:100, boxShadow:'4px 0 32px rgba(0,0,0,0.25)' },
  logoBox:{ display:'flex', alignItems:'center', gap:12, padding:'28px 20px 20px' },
  logoCircle:{ fontSize:32, background:'rgba(13,148,136,0.25)', borderRadius:14, width:50, height:50, display:'flex', alignItems:'center', justifyContent:'center' },
  logoName:{ color:'#fff', fontWeight:800, fontSize:13 },
  logoSub:{ color:'#5eead4', fontSize:11, marginTop:2 },
  divider:{ height:1, background:'rgba(255,255,255,0.07)', margin:'4px 16px' },
  navItem:{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderRadius:12, color:'rgba(255,255,255,0.6)', cursor:'pointer', fontSize:14, fontWeight:500, marginBottom:4, position:'relative', transition:'all 0.25s ease' },
  navActive:{ background:'rgba(13,148,136,0.25)', color:'#5eead4', fontWeight:700 },
  navDot:{ position:'absolute', right:12, width:6, height:6, borderRadius:'50%', background:'#0d9488' },
  docCard:{ display:'flex', alignItems:'center', gap:10, margin:'8px 12px', background:'rgba(255,255,255,0.05)', borderRadius:12, padding:'12px 14px' },
  docAvatar:{ fontSize:26, background:'rgba(13,148,136,0.25)', borderRadius:'50%', width:42, height:42, display:'flex', alignItems:'center', justifyContent:'center' },
  docName:{ color:'#fff', fontSize:12, fontWeight:700 },
  docRole:{ color:'#5eead4', fontSize:11 },
  logoutBtn:{ display:'flex', alignItems:'center', gap:10, padding:'14px 24px', color:'rgba(255,255,255,0.45)', cursor:'pointer', fontSize:13, borderRadius:12, margin:'0 10px 16px', transition:'all 0.2s' },
  main:{ marginLeft:240, flex:1, minHeight:'100vh' },
  topBar:{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'24px 28px', background:'rgba(255,255,255,0.05)', backdropFilter:'blur(16px)', borderBottom:'1px solid rgba(255,255,255,0.08)', marginBottom:24, position:'relative', zIndex:1, flexWrap:'wrap', gap:12 },
  pageTitle:{ color:'#fff', fontSize:22, fontWeight:800 },
  pageSub:{ color:'rgba(255,255,255,0.4)', fontSize:13, marginTop:4 },
  backBtn:{ background:'rgba(255,255,255,0.07)', color:'#5eead4', border:'1px solid rgba(94,234,212,0.25)', padding:'10px 20px', borderRadius:10, cursor:'pointer', fontSize:13, fontWeight:600, transition:'all 0.2s' },
  section:{ background:'rgba(255,255,255,0.05)', backdropFilter:'blur(20px)', border:'1px solid rgba(255,255,255,0.09)', borderRadius:20, padding:28, marginBottom:20 },
  sectionHead:{ display:'flex', alignItems:'center', gap:14, marginBottom:24, paddingBottom:16, borderBottom:'1px solid rgba(255,255,255,0.07)' },
  sIcon:{ fontSize:26, background:'rgba(13,148,136,0.25)', borderRadius:12, width:48, height:48, display:'flex', alignItems:'center', justifyContent:'center' },
  sTitle:{ color:'#fff', fontWeight:700, fontSize:16 },
  sSub:{ color:'rgba(255,255,255,0.4)', fontSize:12, marginTop:2 },
  grid2:{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:20 },
  inp:{ padding:'13px 16px', background:'rgba(255,255,255,0.07)', border:'1.5px solid rgba(255,255,255,0.1)', borderRadius:12, color:'#fff', fontSize:14, outline:'none', transition:'all 0.2s', fontFamily:"'Segoe UI',sans-serif", width:'100%', boxSizing:'border-box' },
  pdfZone:{ display:'block', border:'2px dashed rgba(94,234,212,0.3)', borderRadius:16, padding:'36px 24px', cursor:'pointer', transition:'all 0.2s', background:'rgba(13,148,136,0.05)', textAlign:'center' },
  submitBtn:{ padding:'13px 32px', background:'linear-gradient(135deg,#0d9488,#0f766e)', color:'#fff', border:'none', borderRadius:12, fontSize:15, fontWeight:700, cursor:'pointer', boxShadow:'0 4px 20px rgba(13,148,136,0.4)', transition:'all 0.2s' },
  cancelBtn:{ padding:'13px 24px', background:'rgba(255,255,255,0.06)', color:'rgba(255,255,255,0.55)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:12, fontSize:15, fontWeight:600, cursor:'pointer', transition:'all 0.2s' },
};